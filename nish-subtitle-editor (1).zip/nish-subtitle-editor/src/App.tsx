import { useEffect, useMemo, useRef, useState } from 'react'
import { Activity, AudioLines, Captions, Check, ChevronDown, Clapperboard, Download, FileUp, Film, FolderOpen, Languages, LoaderCircle, MonitorPlay, Plus, Scissors, Settings2, Sparkles, Trash2, Type, Upload, Video, WandSparkles, X } from 'lucide-react'
import { FFmpeg } from '@ffmpeg/ffmpeg'
import { fetchFile, toBlobURL } from '@ffmpeg/util'

type Cue = { id: number; start: number; end: number; text: string }
const starter: Cue[] = [
  { id: 1, start: 0.8, end: 3.2, text: 'Every story begins with a single moment.' },
  { id: 2, start: 3.5, end: 6.4, text: 'Make every word count.' },
  { id: 3, start: 6.8, end: 10.5, text: 'Create subtitles that feel like part of the film.' },
]
const fmt = (n: number) => {
  const t = Math.max(0, n || 0), h = Math.floor(t / 3600), m = Math.floor((t % 3600) / 60), s = Math.floor(t % 60), ms = Math.floor((t % 1) * 1000)
  return `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')},${String(ms).padStart(3,'0')}`
}
const stamp = (n: number) => fmt(n).replace(',', '.')
function parseSrt(raw: string): Cue[] {
  const blocks = raw.replace(/\r/g, '').trim().split(/\n\s*\n/)
  const cues: Cue[] = []
  blocks.forEach((block, i) => {
    const lines = block.split('\n')
    const ti = lines.findIndex(line => line.includes('-->'))
    if (ti < 0) return
    const [a,b] = lines[ti].split('-->').map(v => v.trim().split(/\s+/)[0])
    const toSeconds = (v: string) => { const p = v.replace(',', '.').split(':'); return Number(p[0])*3600 + Number(p[1])*60 + Number(p[2]) }
    const start = toSeconds(a), end = toSeconds(b)
    if (Number.isFinite(start) && Number.isFinite(end)) cues.push({ id: Date.now()+i, start, end: Math.max(start+.1,end), text: lines.slice(ti+1).join('\n') })
  })
  return cues
}
function makeSrt(cues: Cue[]) {
  return [...cues].sort((a,b)=>a.start-b.start).map((c,i)=>`${i+1}\n${fmt(c.start)} --> ${fmt(c.end)}\n${c.text}`).join('\n\n') + '\n'
}
function saveFile(name: string, content: BlobPart, type: string) {
  const url = URL.createObjectURL(new Blob([content], {type})), a = document.createElement('a')
  a.href = url; a.download = name; a.click(); URL.revokeObjectURL(url)
}
export default function App() {
  const [cues,setCues] = useState<Cue[]>(starter)
  const [active,setActive] = useState(1)
  const [videoUrl,setVideoUrl] = useState('')
  const [videoName,setVideoName] = useState('No video loaded')
  const [duration,setDuration] = useState(30)
  const [current,setCurrent] = useState(1.5)
  const [fontSize,setFontSize] = useState(28)
  const [fontColor,setFontColor] = useState('#ffffff')
  const [accent,setAccent] = useState('#8b7cff')
  const [outline,setOutline] = useState(true)
  const [bold,setBold] = useState(true)
  const [animation,setAnimation] = useState('pop')
  const [status,setStatus] = useState('Ready to edit')
  const [busy,setBusy] = useState(false)
  const [ffmpegReady,setFfmpegReady] = useState(false)
  const [tab,setTab] = useState<'subtitles'|'style'>('subtitles')
  const videoRef = useRef<HTMLVideoElement>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const srtRef = useRef<HTMLInputElement>(null)
  const ffmpegRef = useRef<FFmpeg | null>(null)
  const selected = cues.find(c=>c.id===active) || cues[0]
  const currentCue = useMemo(()=>cues.find(c=>current>=c.start && current<=c.end),[cues,current])

  useEffect(()=>{ return ()=>{ if(videoUrl) URL.revokeObjectURL(videoUrl) } },[videoUrl])
  useEffect(()=>{ if(videoRef.current && videoUrl) videoRef.current.src=videoUrl },[videoUrl])
  const updateCue = (id:number, patch:Partial<Cue>) => setCues(old=>old.map(c=>c.id===id?{...c,...patch}:c))
  const uploadVideo = (file?:File) => {
    if(!file) return
    if(!file.type.startsWith('video/')) { setStatus('Choose a video file such as MP4, WebM or MOV.'); return }
    if(videoUrl) URL.revokeObjectURL(videoUrl)
    setVideoUrl(URL.createObjectURL(file)); setVideoName(file.name); setStatus('Video loaded locally')
  }
  const loadSrt = async (file?:File) => {
    if(!file) return
    const parsed = parseSrt(await file.text())
    if(!parsed.length) { setStatus('Could not read this subtitle file. Please use a valid SRT or VTT file.'); return }
    setCues(parsed); setActive(parsed[0].id); setStatus(`${parsed.length} subtitle lines imported`)
  }
  const addCue = () => {
    const id=Date.now(), start=Math.max(0,current), next={id,start,end:start+2,text:'Type your subtitle here'}
    setCues(old=>[...old,next]); setActive(id); setStatus('Subtitle line added')
  }
  const removeCue = () => {
    if(!selected) return
    const rest=cues.filter(c=>c.id!==selected.id); setCues(rest); setActive(rest[0]?.id || 0); setStatus('Subtitle line deleted')
  }
  const seek = (time:number) => { setCurrent(time); if(videoRef.current) videoRef.current.currentTime=time }
  const playAt = (cue:Cue) => { seek(cue.start); setActive(cue.id); videoRef.current?.play().catch(()=>{}) }
  const transcribe = async () => {
    if(!videoRef.current || !videoUrl) { setStatus('Upload a video before starting AI transcription.'); return }
    setBusy(true); setStatus('Preparing audio for AI transcription…')
    try {
      // Extract a mono 16 kHz WAV in the browser so the API receives audio, not a video container.
      const original = (window as any).__substudioFile as File | undefined
      if(!original) { setStatus('Please re-select your video using Upload Video, then try again.'); setBusy(false); return }
      const ff = await loadFFmpeg()
      const ext=(original.name.split('.').pop()||'mp4').toLowerCase().replace(/[^a-z0-9]/g,'')
      const input=`transcribe-input.${ext}`
      await ff.writeFile(input, await fetchFile(original))
      await ff.exec(['-i', input, '-vn', '-ac', '1', '-ar', '16000', '-f', 'wav', 'transcribe-audio.wav'])
      const audio = await ff.readFile('transcribe-audio.wav')
      const form = new FormData()
      form.append('audio', new Blob([audio as BlobPart], {type:'audio/wav'}), 'transcribe-audio.wav')
      const res = await fetch('http://localhost:8787/api/transcribe',{method:'POST',body:form})
      const data = await res.json()
      if(!res.ok) throw new Error(data.error || 'Transcription request failed')
      const segments = (data.segments || []).map((s:any,i:number)=>({id:Date.now()+i,start:Number(s.start)||0,end:Math.max(Number(s.end)||1,(Number(s.start)||0)+.2),text:String(s.text||'').trim()})).filter((c:Cue)=>c.text)
      if(!segments.length && data.text) segments.push({id:Date.now(),start:0,end:Math.max(2,duration),text:data.text})
      setCues(segments); setActive(segments[0]?.id||0); setStatus(`AI created ${segments.length} subtitle lines`)
    } catch(e:any) { setStatus(e.message || 'AI transcription failed. Start the API server and configure your key.') }
    finally { setBusy(false) }
  }
  const loadFFmpeg = async () => {
    if(ffmpegRef.current && ffmpegReady) return ffmpegRef.current
    setStatus('Loading video export engine. First load can take a little while…')
    const ff = new FFmpeg()
    ff.on('log', ({message})=>{ if(message.toLowerCase().includes('error')) console.warn(message) })
    const base='https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.10/dist/esm'
    await ff.load({coreURL:await toBlobURL(`${base}/ffmpeg-core.js`,'text/javascript'),wasmURL:await toBlobURL(`${base}/ffmpeg-core.wasm`,'application/wasm')})
    ffmpegRef.current=ff; setFfmpegReady(true); return ff
  }
  const exportVideo = async () => {
    const original=(window as any).__substudioFile as File|undefined
    if(!original) { setStatus('Upload a video first.'); return }
    setBusy(true)
    try {
      const ff=await loadFFmpeg()
      setStatus('Rendering subtitled video. Please keep this tab open…')
      const ext=(original.name.split('.').pop()||'mp4').toLowerCase().replace(/[^a-z0-9]/g,'')
      const input=`input.${ext}`, output='nish-export.mp4'
      await ff.writeFile(input,await fetchFile(original))
      const srt=makeSrt(cues).replace(/,/g,'.')
      await ff.writeFile('captions.srt',new TextEncoder().encode(srt))
      const style=`FontName=Arial,FontSize=${Math.round(fontSize*0.7)},PrimaryColour=&H${fontColor.slice(5,7)}${fontColor.slice(3,5)}${fontColor.slice(1,3)}&,Outline=${outline?2:0},Bold=${bold?1:0},Alignment=2,MarginV=35`
      await ff.exec(['-i',input,'-vf',`subtitles=captions.srt:force_style='${style}'`,'-c:a','copy','-preset','ultrafast',output])
      const data=await ff.readFile(output)
      saveFile('nish-subtitled.mp4',data as Uint8Array,'video/mp4')
      setStatus('Subtitled MP4 exported successfully')
    } catch(e:any) { setStatus(`Video export failed: ${e.message || 'unsupported input or browser limit'}`) }
    finally { setBusy(false) }
  }
  const exportVtt = () => {
    const vtt=[...cues].sort((a,b)=>a.start-b.start).map(c=>`${stamp(c.start)} --> ${stamp(c.end)}\n${c.text}`).join('\n\n')
    saveFile('nish-subtitles.vtt','WEBVTT\n\n'+vtt,'text/vtt'); setStatus('VTT file exported')
  }

  return <div className="app-shell">
    <header className="topbar">
      <div className="brand"><div className="brand-mark"><Captions size={22}/></div><span>Sub<span className="brand-accent">Studio</span></span><span className="beta">BETA</span></div>
      <div className="project-name"><Film size={15}/><span>Untitled project</span><ChevronDown size={14}/></div>
      <div className="top-actions"><span className="save-state"><span className="dot"/> Local project</span><button className="btn btn-quiet" onClick={()=>srtRef.current?.click()}><FolderOpen size={15}/> Import SRT</button><button className="btn btn-primary" onClick={()=>saveFile('nish-subtitles.srt',makeSrt(cues),'text/plain')}><Download size={15}/> Export SRT</button></div>
    </header>

    <main className="workspace">
      <aside className="left-panel">
        <div className="panel-heading"><span>PROJECT</span><Settings2 size={15}/></div>
        <button className="upload-card" onClick={()=>fileRef.current?.click()}>
          <div className="upload-icon"><Upload size={21}/></div><strong>Upload video</strong><span>MP4, WebM, MOV</span><small>Files stay in your browser for editing</small>
        </button>
        <input ref={fileRef} type="file" accept="video/*,audio/*" hidden onChange={e=>{const f=e.target.files?.[0]; if(f){(window as any).__substudioFile=f;uploadVideo(f)};e.currentTarget.value=''}}/>
        <input ref={srtRef} type="file" accept=".srt,.vtt,text/plain" hidden onChange={e=>{void loadSrt(e.target.files?.[0]);e.currentTarget.value=''}}/>
        <div className="media-file"><div className="file-icon"><Video size={17}/></div><div className="file-copy"><strong>{videoName}</strong><span>{videoUrl?'Ready to preview':'Add media to begin'}</span></div>{videoUrl&&<Check size={15} className="green"/>}</div>
        <div className="panel-heading subtitle-title"><span>SUBTITLES <b>{cues.length}</b></span><button className="icon-btn" onClick={addCue} title="Add subtitle"><Plus size={16}/></button></div>
        <div className="cue-list">{cues.map((cue,i)=><button key={cue.id} className={`cue-item ${active===cue.id?'selected':''}`} onClick={()=>{setActive(cue.id);seek(cue.start)}}><span className="cue-index">{String(i+1).padStart(2,'0')}</span><span className="cue-copy"><span>{cue.text || 'Empty subtitle'}</span><small>{stamp(cue.start).slice(3,11)} – {stamp(cue.end).slice(3,11)}</small></span></button>)}</div>
        <button className="add-cue" onClick={addCue}><Plus size={15}/> Add subtitle line</button>
        <div className="left-bottom"><div className="status-icon"><Activity size={15}/></div><div><strong>Workspace status</strong><span>{busy?'Working…':'Autosave is local to this session'}</span></div></div>
      </aside>

      <section className="center-panel">
        <div className="preview-header"><div className="preview-label"><MonitorPlay size={16}/><strong>Preview</strong><span className="live-pill">LIVE</span></div><div className="preview-tools"><span>16:9</span><span>·</span><span>{Math.round(duration)} sec</span></div></div>
        <div className="preview-stage">
          <div className="video-frame">
            {videoUrl?<video ref={videoRef} src={videoUrl} controls onLoadedMetadata={e=>setDuration(e.currentTarget.duration||30)} onTimeUpdate={e=>setCurrent(e.currentTarget.currentTime)} onEnded={()=>setStatus('Playback complete')} />:<div className="empty-preview"><div className="empty-symbol"><Clapperboard size={34}/></div><strong>Your video preview</strong><span>Upload a video to see your subtitles in action</span><button className="btn btn-primary" onClick={()=>fileRef.current?.click()}><FileUp size={15}/> Choose video</button></div>}
            {videoUrl&&currentCue&&<div className={`subtitle-overlay ${bold?'is-bold':''} anim-${animation}`} style={{fontSize:`${fontSize}px`,color:fontColor,textShadow:outline?'0 2px 3px #000, 2px 0 3px #000, -2px 0 3px #000, 0 -2px 3px #000':'none'}}>{currentCue.text}</div>}
          </div>
        </div>
        <div className="transport"><button className="transport-btn" onClick={()=>seek(Math.max(0,current-5))}>−5s</button><button className="transport-btn" onClick={()=>seek(0)}>↤</button><span className="time-readout">{stamp(current)} <i>/</i> {stamp(duration)}</span><button className="transport-btn" onClick={()=>seek(Math.min(duration,current+5))}>+5s</button><button className="transport-btn" onClick={()=>{if(videoRef.current){videoRef.current.paused?videoRef.current.play():videoRef.current.pause()}}}>▶ / ❚❚</button></div>
        <div className="timeline-panel">
          <div className="timeline-top"><div><AudioLines size={15}/><strong>Timeline</strong></div><span>Drag-free MVP · click a block to seek</span></div>
          <div className="timeline-ruler"><span>00:00</span><span>00:10</span><span>00:20</span><span>00:30</span><span>{stamp(duration).slice(3,8)}</span></div>
          <div className="timeline-track"><div className="track-label"><Video size={14}/> VIDEO</div><div className="track-lane">{videoUrl&&<div className="video-clip" style={{width:'100%'}}>{videoName}</div>}</div></div>
          <div className="timeline-track"><div className="track-label"><Captions size={14}/> TEXT</div><div className="track-lane cue-lane">{cues.map(c=><button key={c.id} title={c.text} onClick={()=>playAt(c)} className={`timeline-clip ${active===c.id?'is-active':''}`} style={{left:`${Math.max(0,c.start/Math.max(duration,1))*100}%`,width:`${Math.max(2,(c.end-c.start)/Math.max(duration,1)*100)}%`}}>{c.text}</button>)}</div></div>
          <div className="playhead" style={{left:`calc(132px + (100% - 150px) * ${Math.min(1,current/Math.max(duration,1))})`}}/>
        </div>
        <div className="bottom-bar"><span><span className="dot"/> {status}</span><span>{cues.length} subtitle segments <i>·</i> {videoUrl?'Video loaded':'No video loaded'}</span></div>
      </section>

      <aside className="right-panel">
        <div className="right-tabs"><button className={tab==='subtitles'?'active':''} onClick={()=>setTab('subtitles')}><Type size={15}/> Edit</button><button className={tab==='style'?'active':''} onClick={()=>setTab('style')}><WandSparkles size={15}/> Style</button></div>
        {tab==='subtitles'?<div className="inspector-content">
          <div className="section-title"><span>SUBTITLE TEXT</span>{selected&&<span className="tiny-badge">#{String(cues.findIndex(c=>c.id===selected.id)+1).padStart(2,'0')}</span>}</div>
          {selected?<><textarea className="subtitle-input" value={selected.text} onChange={e=>updateCue(selected.id,{text:e.target.value})} rows={4} placeholder="Type subtitle text…"/>
          <div className="field-grid"><label>Start time<input type="number" min="0" step=".1" value={selected.start} onChange={e=>updateCue(selected.id,{start:Math.max(0,Number(e.target.value))})}/></label><label>End time<input type="number" min=".1" step=".1" value={selected.end} onChange={e=>updateCue(selected.id,{end:Math.max(selected.start+.1,Number(e.target.value))})}/></label></div>
          <div className="button-row"><button className="btn btn-quiet" onClick={()=>playAt(selected)}>Preview line</button><button className="btn btn-danger" onClick={removeCue}><Trash2 size={14}/> Delete</button></div></>:<div className="no-selection">Select or add a subtitle line to edit it.</div>}
          <div className="section-title separated"><span>AI TOOLS</span><Sparkles size={14}/></div>
          <div className="ai-card"><div className="ai-icon"><Languages size={17}/></div><div className="ai-copy"><strong>Auto-transcribe</strong><span>Generate timed subtitles from your media.</span></div></div>
          <button className="btn btn-ai" disabled={busy} onClick={()=>void transcribe()}>{busy?<LoaderCircle size={15} className="spin"/>:<Sparkles size={15}/>} {busy?'Working…':'Generate subtitles with AI'}</button>
          <p className="helper-text">Requires the local API server and a Google Gemini API key. Audio is processed by Google; upload limits apply.</p>
          <div className="section-title separated"><span>EXPORT</span><Download size={14}/></div>
          <button className="export-option" onClick={()=>saveFile('nish-subtitles.srt',makeSrt(cues),'text/plain')}><div className="export-icon">SRT</div><div><strong>Subtitle file</strong><span>Download .srt with timings</span></div><Download size={15}/></button>
          <button className="export-option" onClick={exportVtt}><div className="export-icon">VTT</div><div><strong>Web captions</strong><span>Download .vtt file</span></div><Download size={15}/></button>
          <button className="btn btn-primary full" disabled={busy||!videoUrl} onClick={()=>void exportVideo()}><Film size={15}/>{busy?'Rendering…':'Render video with subtitles'}</button>
          <p className="helper-text">MP4 rendering uses FFmpeg.wasm in your browser and can be slow for large files.</p>
        </div>:<div className="inspector-content">
          <div className="section-title"><span>CAPTION STYLE</span><Type size={14}/></div>
          <label className="range-label">Font size <strong>{fontSize}px</strong></label><input className="range" type="range" min="16" max="54" value={fontSize} onChange={e=>setFontSize(Number(e.target.value))}/>
          <div className="style-field"><label>Text colour</label><div className="color-control"><input type="color" value={fontColor} onChange={e=>setFontColor(e.target.value)}/><span>{fontColor.toUpperCase()}</span></div></div>
          <div className="style-field"><label>Accent colour</label><div className="color-control"><input type="color" value={accent} onChange={e=>setAccent(e.target.value)}/><span>{accent.toUpperCase()}</span></div></div>
          <div className="toggle-row"><div><strong>Bold text</strong><span>Heavier caption weight</span></div><button className={`toggle ${bold?'on':''}`} onClick={()=>setBold(!bold)}><span/></button></div>
          <div className="toggle-row"><div><strong>Text outline</strong><span>Improve contrast over video</span></div><button className={`toggle ${outline?'on':''}`} onClick={()=>setOutline(!outline)}><span/></button></div>
          <div className="section-title separated"><span>TEXT ANIMATION</span><Sparkles size={14}/></div>
          <label className="style-field"><label>Animation preset</label><select className="animation-select" value={animation} onChange={e=>setAnimation(e.target.value)}><option value="pop">Pop In</option><option value="fade">Soft Fade</option><option value="bounce">Bounce</option><option value="type">Typewriter</option><option value="glow">Neon Glow</option><option value="slide">Slide Up</option><option value="karaoke">Karaoke Highlight</option><option value="none">No Animation</option></select></label>
          <p className="helper-text">Animations preview while the active subtitle is visible. Animated MP4 export is a later rendering upgrade; SRT/VTT exports contain text and timings only.</p>
          <div className="section-title separated"><span>QUICK PRESETS</span><Sparkles size={14}/></div>
          <button className="preset-card" onClick={()=>{setFontSize(28);setFontColor('#ffffff');setBold(true);setOutline(true)}}><span className="preset-preview">Aa</span><span><strong>Classic subtitle</strong><small>White · bold · outlined</small></span><Check size={15}/></button>
          <button className="preset-card" onClick={()=>{setFontSize(36);setFontColor('#ffe36e');setBold(true);setOutline(true)}}><span className="preset-preview yellow">Aa</span><span><strong>Creator highlight</strong><small>Warm yellow · bold</small></span></button>
          <button className="preset-card" onClick={()=>{setFontSize(24);setFontColor('#ffffff');setBold(false);setOutline(true)}}><span className="preset-preview minimal">Aa</span><span><strong>Minimal</strong><small>Smaller · clean</small></span></button>
        </div>}
      </aside>
    </main>
    <footer className="footer"><span>NISH <b>0.1.0</b></span><span>Made for creators · Your media stays local for editing</span><span><Scissors size={13}/> Cut, caption, create.</span></footer>
  </div>
}