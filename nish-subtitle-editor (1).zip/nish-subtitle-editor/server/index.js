import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import multer from 'multer'
import { GoogleGenAI } from '@google/genai'

const app = express()
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 18 * 1024 * 1024 } })
app.use(cors({ origin: process.env.CLIENT_ORIGIN || 'http://localhost:5173' }))
app.get('/api/health', (_req, res) => res.json({ ok: true, aiConfigured: Boolean(process.env.GEMINI_API_KEY) }))

app.post('/api/transcribe', upload.single('audio'), async (req, res) => {
  if (!process.env.GEMINI_API_KEY) return res.status(503).json({ error: 'Google Gemini is not configured. Add GEMINI_API_KEY to your .env file and restart the API server.' })
  if (!req.file) return res.status(400).json({ error: 'Please upload a video or audio file first.' })
  try {
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY })
    const mimeType = req.file.mimetype || 'audio/wav'
    const prompt = `Transcribe this audio into subtitle segments. Detect the spoken language automatically. Return ONLY valid JSON with this exact shape: {"text":"full transcript","segments":[{"start":0.0,"end":2.1,"text":"spoken words"}]}. Use seconds for start/end. Create readable subtitle chunks, usually 2–8 words per cue, keep each cue under about 42 characters when possible, preserve the original language, and estimate timestamps carefully. Do not include markdown fences or commentary.`
    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: [{ role: 'user', parts: [
        { inlineData: { mimeType, data: req.file.buffer.toString('base64') } },
        { text: prompt }
      ] }],
      config: { responseMimeType: 'application/json' }
    })
    let data
    try { data = JSON.parse(response.text || '{}') } catch { throw new Error('Gemini returned an unexpected response. Please try a shorter audio clip.') }
    const segments = Array.isArray(data.segments) ? data.segments.filter(s => typeof s.text === 'string').map(s => ({ start: Math.max(0, Number(s.start) || 0), end: Math.max((Number(s.start)||0)+0.2, Number(s.end)||1), text: s.text.trim() })).filter(s => s.text) : []
    res.json({ text: String(data.text || ''), segments })
  } catch (error) {
    console.error('Gemini transcription error:', error?.message || error)
    res.status(500).json({ error: error?.message || 'Gemini transcription failed. Check API key, account access, supported audio format and server terminal.' })
  }
})
const port = Number(process.env.PORT || 8787)
app.listen(port, () => console.log(`NISH Google API running at http://localhost:${port}`))
